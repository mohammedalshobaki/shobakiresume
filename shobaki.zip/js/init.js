if (typeof firebase === 'undefined') throw new Error('hosting/init-error: Firebase SDK not detected. You must include it before /__/firebase/init.js');
firebase.initializeApp({
  "apiKey": "AIzaSyDEyBrFmxwxROTGoTuITUYXoO0hVu9DCpw",
  "appId": "1:362798269697:web:c56583fa3157de967c4700",
  "authDomain": "joisarjignesh10.firebaseapp.com",
  "databaseURL": "https://joisarjignesh10.firebaseio.com",
  "measurementId": "G-S8B09W0ZHC",
  "messagingSenderId": "362798269697",
  "projectId": "joisarjignesh10",
  "storageBucket": "joisarjignesh10.appspot.com"
});